/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;


import java.util.ArrayList;
import model.Admission;
import model.SignUp;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Willy
 */
public class GeneralDao {
    

      public static void addUser(Admission adm){
      try{
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = session.beginTransaction();
        session.save(adm);
        tr.commit();
        session.close();   
      }catch(Exception ex){
        ex.printStackTrace();   
      }
  }
//  
//  public static void InsertStudentUser(Admission adm, String email){
//      try{
//        Session session = HibernateUtil.getSessionFactory().openSession();
//        Transaction tr = session.beginTransaction();
//        session.save(adm);
//        tr.commit();
//        session.close();  
//      }catch(Exception ex){
//        ex.printStackTrace();   
//      }
//  }
//  
//  public static ArrayList<Admission>selectAllUsers(){
//     ArrayList<Admission> list = new ArrayList<>();
//     Session session = HibernateUtil.getSessionFactory().openSession();
//     session.beginTransaction();
//     list = (ArrayList)session.createQuery("from admissions").list();
//     session.getTransaction().commit();
//     session.close();
//     return list;
//  }
//  
//  public static Admission findUser(Admission adm){
//      Session session = HibernateUtil.getSessionFactory().openSession();
//      Admission RespUser = (Admission)session.get(Admission.class, adm.getEmail());
//      session.close();
//      return adm;
//  }
//  
  public static ArrayList<SignUp> AuthenticateUser(SignUp su){
       //User user= new User();
//       SignUp Signuser = new SignUp();
//    Session session = HibernateUtil.getSessionFactory().openSession();
//        try {
//            
//            Query q = session.createQuery("from signUp u where u.email=:email");
//            q.setParameter("email", su.getClass() );
//            Signuser = (SignUp) q.uniqueResult();
//            session.close();
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return Signuser;
      Session session = HibernateUtil.getSessionFactory().openSession();
    ArrayList<SignUp>list=new ArrayList<>();
        try {
            
            Query q = session.createQuery("from SignUp");
            list=(ArrayList<SignUp>) q.list();
            
            session.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
  }
  public static void signUp(SignUp sp){
      try{
        Session session = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = session.beginTransaction();
        session.save(sp);
        tr.commit();
        session.close();   
      }catch(Exception ex){
         ex.printStackTrace();
      }
  }
  
  public static ArrayList<Admission>selectAllStudents(){
     ArrayList<Admission> list = new ArrayList<>();
     Session session = HibernateUtil.getSessionFactory().openSession();
     session.beginTransaction();
     list = (ArrayList)session.createQuery("from admissions").list();
     session.getTransaction().commit();
     session.close();
     return list;
  }
  
//  
//  //Transaction transaction;
//  public static void deleteStudent(int id) {
//
//		
//		try  {
//                      Session session = HibernateUtil.getSessionFactory().openSession();
//			// start a transaction
//			Transaction transaction = session.beginTransaction();
//
//			// Delete a student object
//			Admission adm = (Admission) session.get(Admission.class, id);
//			if (adm != null) {
//				session.delete(adm);
//				//System.out.println("student is deleted");
//			}
//
//			// commit transaction
//			transaction.commit();
//		} catch (Exception e) {
//			
//			e.printStackTrace();
//		}
//	}
//    public static Admission getStudent(int id) {
//	Admission adm = null;
//		try  {
//                    Session session = HibernateUtil.getSessionFactory().openSession();
//			// start a transaction
//			Transaction transaction = session.beginTransaction();
//			// get an student object
//			adm = (Admission) session.get(Admission.class, id);
//			// commit transaction
//			transaction.commit();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return adm;
//	}
//        
//    public static void updateStudent(Admission adm) {
//		
//		try   {
//                  Session session = HibernateUtil.getSessionFactory().openSession();
//			// start a transaction
//			Transaction transaction = session.beginTransaction();
//			// save the student object
//			session.update(adm);
//			// commit transaction
//			transaction.commit();
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
  public static String getStudentEmailById(Long studentId) {
    String email = null;
    try {
        Session session = HibernateUtil.getSessionFactory().openSession();
        session.beginTransaction();

      
        Query query = session.createQuery("SELECT email FROM admissions WHERE studentId = :id");
        query.setParameter("id", studentId);
        
        email = (String) query.uniqueResult();

        session.getTransaction().commit();
        session.close();
    } catch (Exception ex) {
        ex.printStackTrace();
    }
    return email;
}
public static boolean checkCredentials(String email, String password) {
    Session session = HibernateUtil.getSessionFactory().openSession();
    try {
        session.beginTransaction();

        // Assuming that the 'password' field in the database is already hashed
        Query query = session.createQuery("FROM SignUp WHERE email = :email AND password = :password");
        query.setParameter("email", email.trim());
        query.setParameter("password", password); // Assuming passwords are stored as hashed

        SignUp user = (SignUp) query.uniqueResult();

        session.getTransaction().commit();
        
        return user != null;
    } catch (HibernateException ex) {
        ex.printStackTrace();
        // Handle the exception as needed, e.g., log it or throw a custom exception
    } finally {
        if (session != null && session.isOpen()) {
            session.close();
        }
    }
    
    return false; // Default to false in case of exceptions
}




    
}
