/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import com.sun.faces.action.RequestMapping;
import dao.GeneralDao;
import email.Mail;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import model.Admission;

/**
 *
 * @author Willy
 */
@WebServlet("/")
@MultipartConfig
public class AdmissionServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    @RequestMapping("/add")
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
      DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        
        try (PrintWriter out = response.getWriter()){
             Long std = Long.parseLong(request.getParameter("studentid")); // Parse the parameter as Long
//String studentIdStr = std.toString(); // Convert Long to String

            String fn = request.getParameter("firstname");
             String ln = request.getParameter("lastname");
             String eml = request.getParameter("email");
            String gen = request.getParameter("gender");
            String dept = request.getParameter("dept");
            String fac = request.getParameter("faculty");
           // String dob = request.getParameter("dob");
            Date dateob = formatter.parse(request.getParameter("dob"));
            
            Part fil = request.getPart("files");
            InputStream fileC = fil.getInputStream();
            ByteArrayOutputStream output = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead;
            while((bytesRead = fileC.read(buffer)) != -1){
            output.write(buffer, 0, bytesRead);
            }
            byte[] imageBytes = output.toByteArray();
            
            Part pdf = request.getPart("images");
            
            InputStream fileP = pdf.getInputStream();
            ByteArrayOutputStream outputpdf = new ByteArrayOutputStream();
            byte[] bufferpdf = new byte[1024];
            int bytesReadpdf;
            while((bytesReadpdf = fileP.read(bufferpdf)) != -1){
            output.write(bufferpdf, 0, bytesReadpdf);
            }
            byte[] pdfBytes = outputpdf.toByteArray();
            
            
            Admission adm = new Admission(std, eml,fn, ln, gen, fac, dept, dateob, pdfBytes, imageBytes);
            GeneralDao.addUser(adm);
            
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("home.jsp");
	    dispatcher.forward(request, response);
            
            try {
                
                Mail.sendMail(request.getParameter("email"));
            } catch (Exception ex) {
                Logger.getLogger(AdmissionServlet.class.getName()).log(Level.SEVERE, null, ex);
            }
                    } catch (ParseException ex) {
            Logger.getLogger(AdmissionServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
