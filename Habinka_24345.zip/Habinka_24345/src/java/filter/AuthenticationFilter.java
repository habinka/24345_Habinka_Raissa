/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package filter;

import dao.GeneralDao;
import java.io.IOException;
import java.io.PrintStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.ArrayList;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.SignUp;

/**
 *
 * @author Willy
 */

public class AuthenticationFilter implements Filter {

    public AuthenticationFilter() {
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc)
            throws IOException, ServletException {
//        HttpServletRequest httpRequest = (HttpServletRequest) request;
//        HttpServletResponse httpResponse = (HttpServletResponse) response;
//
//        // Check if the user is authenticated (you can use a session attribute or a cookie)
//        boolean isAuthenticated = false;
//
//        // Retrieve user credentials from the request, e.g., from a session attribute
//        String userEmail = (String) httpRequest.getSession().getAttribute("email");
//        String userPassword = (String) httpRequest.getSession().getAttribute("password");
//
//        // Check the credentials using the GeneralDao method
//        if (userEmail != null && userPassword != null) {
//            isAuthenticated = GeneralDao.checkCredentials(userEmail, userPassword);
//        }
//
//        if (isAuthenticated) {
//            // User is authenticated, allow access to the requested page
//            chain.doFilter(request, response);
//        } else {
//            // User is not authenticated, redirect to the login page
//            httpResponse.sendRedirect(httpRequest.getContextPath() + "/login.jsp");
//        }
         try(PrintWriter out = response.getWriter()){
     String _email = request.getParameter("email");
            String _password = request.getParameter("password");
            SignUp su = new SignUp(_email, _password);
            ArrayList<SignUp> loginUser = GeneralDao.AuthenticateUser(su);

            if (loginUser != null) {
                for (int i = 0; i < loginUser.size(); i++) {
                    if (loginUser.get(i).getUsername().equals(_email)) {
                        if (loginUser.get(i).getPassword().equals(_password)) {

                        fc.doFilter(request, response);
                        }else{
                        
                            RequestDispatcher lg = request.getRequestDispatcher("login.jsp");
                            lg.forward(request, response);
                        }
                        }else{
                    
                            RequestDispatcher lg = request.getRequestDispatcher("login.jsp");
                            lg.forward(request, response);
                    }
                }
            }
    }


    
    }

    @Override
    public void destroy() {
    }
}