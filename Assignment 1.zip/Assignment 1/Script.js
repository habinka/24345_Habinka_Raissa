function register() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // Perform registration logic (you can send data to the server here)
    console.log('Registering user:', username);

    // Redirect to login page after registration
    window.location.href = 'login.html';
}

function login() {
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    // Perform login logic (you can send data to the server here)
    console.log('Logging in user:', username);

    // Redirect to another page after login (e.g., dashboard)
    // For simplicity, redirecting to index.html
    window.location.href = 'index.html';
}
